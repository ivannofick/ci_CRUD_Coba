<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Siswa extends CI_Controller{
	private $alert='';
	public function __construct(){
		parent:: __construct();
		$this->load->helper('url');
		$this->load->model('siswaModel');
	}
	public function index(){
		$data['semua'] = $this->siswaModel->all();
		$this->tampilan('list',$data);
	}
	private function tampilan($content,$data=null){
		$data['content']= $this->load->view($content,$data,true);
		$this->load->view('tampilan',$data);
	}
	private function alert($open_tag=null, $close_tag=null,$data=null){
		if ($data!=null)$data = $open_tag.$data.$close_tag;
		return $data;
	}
	public function form(){
		if ($this->input->post('simpan')) {
			$array = array(
					'nama'=>$this->input->post('nama'),
					'tangal'=>$this->input->post('tangal'),
					'jurusan'=>$this->input->post('jurusan'),
					'alamat'=>$this->input->post('alamat'),
					'nomer'=>$this->input->post('nomer'),
					'kelamin'=>$this->input->post('kelamin'),
				);
			if ($this->input->post('nim')=='') {
				if ($this->siswaModel->insert($array)) {
					$this->alert = $this->alert("<p class='alert alert-success'>","</p>","data berhasil dimasukan");
				}else{
					$this->alert = $this->alert("<p class='alert-danger'>","</p>","mohon cek kembali");
				}
			}else{
				if ($this->siswaModel->update($array,array('nim'=>$this->input->post('nim')))) {

					$this->alert = $this->alert("<p class='alert alert-success'>","</p>","Sukses Menyimpan");
				}else{
					$this->alert = $this->alert("<p class='alert-danger'>","</p>","maaf data tidak bisa diperbarui");
				}
			}
		}
		$data['satu'] = $this->siswaModel->getwhere(array('nim'=>$this->uri->segment(3)))->row_array();
		$data['alert'] = $this->alert;
		$this->tampilan('form',$data);
	}
	public function hapus(){
		if ($this->uri->segment(3)) $this->siswaModel->delete(array('nim'=>$this->uri->segment(3)));
		redirect('siswa');
	}
}