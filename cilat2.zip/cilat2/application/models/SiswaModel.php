<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
* 
*/
class SiswaModel extends CI_Model
{
	
	public function __construct(){

		parent::__construct();
		$this->load->database();
	}
	
	public function all(){
		return $this->db->get('siswa');
	}
	public function getwhere($where){
		$this->db->where($where);
		return $this->db->get('siswa');
	}
		public function insert($data){
		return $this->db->insert('siswa',$data);
	}
	public function update($data,$where){
		$this->db->where($where);
		return $this->db->update('siswa',$data);
	}
		public function delete($where){
		return $this->db->delete('siswa',$where);
	}
}