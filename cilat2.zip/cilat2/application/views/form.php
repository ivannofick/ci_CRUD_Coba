<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h1 align="center">Input siswa</h1>
			</div>
			<div class="panel-body">
			<?php echo $alert;?>
				<form method="post" class="form-horizontal">
					<div class="form-group">
						<label class="control-label col-md-2">nama</label>
						<div class="col-md-10">
							<input type="text" class="form-control" value="<?php echo $satu['nama'];?>" name="nama">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-2">tanggal</label>
						<div class="col-md-10">
							<input type="text" class="form-control" value="<?php echo $satu['tangal'];?>" name="tangal">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-2">jurusan</label>
						<div class="col-md-10">
							<input type="text" class="form-control" value="<?php echo $satu['jurusan'];?>" name="jurusan">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-2">alamat</label>
						<div class="col-md-10">
							<input type="text" class="form-control" value="<?php echo $satu['alamat'];?>" name="alamat">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-2">no tlp</label>
						<div class="col-md-10">
							<input type="text" class="form-control" value="<?php echo $satu['nomer'];?>" name="nomer">
						</div>
					</div>
					<div class="form-group">
					<label class="control-label col-md-2">kelamin</label>
						<div class="col-md-10">
							<input type="text" class="form-control" name="kelamin" value="<?php echo $satu['kelamin'];?>">
						</div>
					</div>
					<div class="form-group">
							<div class="col-md-2">
								<input type="hidden" name="nim" value="<?php echo $satu['nim'];?>">
							</div>
							<div class="col-md-10">
								<input type="submit" name="simpan" class="btn btn-primary" value="Simpan">
								<a href="<?php echo site_url();?>" class="btn btn-danger">Kembali</a>
							</div>
						</div>
				</form>
			</div>
		</div>
	</div>
</div>