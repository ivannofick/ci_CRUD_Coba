<div class="row">
	<div class="col-md-12">
		<h1 align="center">Tabel siswa</h1>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<a href="<?php echo site_url('siswa/form');?>" class="btn btn-primary pull-left">ADD</a>

		<table class="table table-striped">
			<thead>
				<tr>
					<th>Nim</th>
					<th>nama</th>
					<th>tanggal lahir</th>
					<th>jurusan</th>
					<th>alamat</th>
					<th>no hp</th>
					<th>Kelamin</th>
				</tr>
			</thead>
			<tbody>
				<?php $n=0;
					foreach ($semua->result_array() as $d) {
						$n++;
				?>
				<tr>
					<td><?php echo $n;?></td>
					<td><?php echo $d['nama'];?></td>
					<td><?php echo $d['tangal'];?></td>
					<td><?php echo $d['jurusan'];?></td>
					<td><?php echo $d['alamat'];?></td>
					<td><?php echo $d['nomer'];?></td>
					<td><?php echo $d['kelamin'];?></td>
					<td>
						<a href="<?php echo site_url('siswa/form/'.$d['nim']);?>" class="btn btn-success">edit</a>
						<a href="<?php echo site_url('siswa/hapus/'.$d['nim']);?>" class="btn btn-danger">hapus</a>		
					</td>
				</tr>
				<?php }?>
			</tbody>
		</table>
	</div>
</div>
