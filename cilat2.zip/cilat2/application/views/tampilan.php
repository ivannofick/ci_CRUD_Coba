<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Data Siswa</title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

	<link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body>

<div id="wrapper">

	<nav class="navbar navbar-inverse">

		<div class="navbar-header">

			<a class="navbar-brand" href="<?php echo site_url();?>
			">Home</a>

		</div>
	</nav>

	<div id="page-wrapper">

		<div class="container-fluid">

			<div class="row">
				<div class="col-md-2">
					
				</div>
				<div class="col-md-8">
					<?php echo $content;?>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="<?php echo base_url();?>assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>
</html>